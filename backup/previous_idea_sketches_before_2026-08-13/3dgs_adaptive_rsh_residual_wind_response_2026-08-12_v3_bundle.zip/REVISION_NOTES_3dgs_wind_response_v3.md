# Revision 3 Notes

## Main architectural change

The always-on local response network is replaced by a unified adaptive representation:

- Each canonical topology-aware patch predicts and caches vector-valued aerodynamic Response SH (RSH).
- Rigid motion is handled by transforming the wind query into the co-rotated patch frame; cached coefficients are not regenerated.
- Intrinsic stretch, shear, bending, twist, and deformation rate produce a continuous deformation-severity gate.
- Active patches receive a direct deformation-conditioned residual in force/acceleration space.
- Cached RSH coefficients are immutable, so no frame-to-frame coefficient drift is introduced.
- A full direct-response network remains a required baseline and runtime fallback.

## Response decomposition

The local response is defined as:

```text
local response
= canonical RSH aerodynamic base
+ deformation gate * (aerodynamic correction + structural/damping residual)
```

The aerodynamic correction scales with current dynamic pressure and vanishes at zero wind. The structural residual uses a non-vanishing bending-based scale, so elastic recovery remains active when wind stops.

## Adaptive runtime

- All patches evaluate low-order RSH every frame.
- Only patches that pass a hysteresis-based deformation gate execute the residual network.
- The document derives a measured break-even active-patch ratio against a full direct network.
- If the active ratio is too high, the framework permits a direct-response fallback instead of assuming the hybrid is always faster.

## Scope update

- Main benchmark: attached or compliant-attached thin surfaces, including flags, pennants, laundry, paper sheets, leaves, petals, and cloth strips.
- Optional extension: detached leaves with analytic Newton-Euler SE(3) motion plus learned body-frame deformation.
- Excluded from the initial paper: paper-airplane flight, full trees, and full two-way fluid-structure interaction.

## Terminology correction

- `RSH`: aerodynamic Response Spherical Harmonics.
- `ASH`: appearance/color Spherical Harmonics.

These are separate coefficient sets, networks, losses, and runtime operations.

## Retained Revision 2 implementation contracts

- conservative anchor area/mass;
- non-canceling Gaussian reliability;
- non-vanishing structural scale;
- rank-2-stable shell map;
- affine MLS as the main Gaussian transport;
- explicit pin, target, reaction force, and reaction torque projection.

## New required tests

- RSH least-squares coefficient recovery;
- rigid-rotation equivariance;
- canonical RSH-only accuracy;
- zero structural residual at rest;
- immutable coefficient/no-drift test;
- gate hysteresis and skip continuity;
- active-ratio break-even profiler validation.
