# Build Instructions

The document uses XeLaTeX and BibTeX.

```bash
xelatex -no-pdf -interaction=nonstopmode -halt-on-error \
  3dgs_adaptive_rsh_residual_wind_response_2026-08-12_v3.tex

bibtex 3dgs_adaptive_rsh_residual_wind_response_2026-08-12_v3

xelatex -no-pdf -interaction=nonstopmode -halt-on-error \
  3dgs_adaptive_rsh_residual_wind_response_2026-08-12_v3.tex
xelatex -no-pdf -interaction=nonstopmode -halt-on-error \
  3dgs_adaptive_rsh_residual_wind_response_2026-08-12_v3.tex

xdvipdfmx -o 3dgs_adaptive_rsh_residual_wind_response_2026-08-12_v3.pdf \
  3dgs_adaptive_rsh_residual_wind_response_2026-08-12_v3.xdv
```

Keep `refs_3dgs_wind_response_v3.bib` in the same directory.

On systems where the `bibtex` alternatives symlink is broken, invoke the installed binary directly, for example `bibtex.original`.
