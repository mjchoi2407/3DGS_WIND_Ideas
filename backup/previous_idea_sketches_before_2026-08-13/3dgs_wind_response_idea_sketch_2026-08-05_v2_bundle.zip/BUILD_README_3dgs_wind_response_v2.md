# Build

The document uses XeLaTeX and BibTeX.

```bash
xelatex -no-pdf -interaction=nonstopmode -halt-on-error \
  3dgs_mesh_privileged_local_global_wind_response_2026-08-05_v2.tex

bibtex 3dgs_mesh_privileged_local_global_wind_response_2026-08-05_v2

xelatex -no-pdf -interaction=nonstopmode -halt-on-error \
  3dgs_mesh_privileged_local_global_wind_response_2026-08-05_v2.tex
xelatex -no-pdf -interaction=nonstopmode -halt-on-error \
  3dgs_mesh_privileged_local_global_wind_response_2026-08-05_v2.tex

xdvipdfmx -o 3dgs_mesh_privileged_local_global_wind_response_2026-08-05_v2.pdf \
  3dgs_mesh_privileged_local_global_wind_response_2026-08-05_v2.xdv
```

Keep `refs_3dgs_wind_response.bib` in the same directory.
