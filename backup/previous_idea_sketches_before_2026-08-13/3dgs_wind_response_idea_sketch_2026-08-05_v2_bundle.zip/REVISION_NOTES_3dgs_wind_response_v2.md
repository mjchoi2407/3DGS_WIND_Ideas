# Revision 2 - Implementation-Critical Corrections

This revision keeps the mesh-privileged / mesh-free-at-inference research direction, but changes several implementation-level definitions that were unsafe in Revision 1.

## 1. Surface-density notation

All malformed or ambiguous forms such as `ho_sh_r` and `rho_sh_r` are replaced by either:

- `rho_{s,r} h_r` for patch surface mass density, or
- `sigma_{m,r}` as the explicit surface-mass-density symbol.

## 2. Conservative anchor area and mass

The mesh-to-anchor weights are normalized for each mesh sample, not for each anchor:

\[
Z_i^\chi=\sum_k \widetilde\chi_{ik},\qquad
\chi_{ik}=\frac{\widetilde\chi_{ik}}{Z_i^\chi},\qquad
\sum_k\chi_{ik}=1.
\]

Anchor targets are:

\[
A_k^*=\sum_i\chi_{ik}A_i^0,\qquad
m_k^*=\sum_i\chi_{ik}m_i.
\]

Therefore:

\[
\sum_k A_k^*=A_{\mathrm{tot}}^*,\qquad
\sum_k m_k^*=M_{\mathrm{tot}}^*.
\]

At inference, area uses a total-plus-share parameterization:

\[
\widehat A_k=\widehat A_{\mathrm{tot}}\pi_k^{\mathrm{area}},\qquad
\sum_k\pi_k^{\mathrm{area}}=1.
\]

## 3. Gaussian reliability no longer cancels

The geometric responsibility and reliability gate are separated:

\[
\pi_{jk}^A=\operatorname{softmax}_k(\ell_{jk}^A),\qquad
\omega_{jk}^A=q_j^G\pi_{jk}^A.
\]

`pi` determines which anchor receives a Gaussian; `omega` determines how much trusted evidence that Gaussian contributes. This avoids the previous cancellation of `q_j^G` inside a per-Gaussian softmax.

## 4. Non-vanishing structural normalization

Instantaneous wind speed is not used as the sole dynamics scale. For a thin shell:

\[
B_r=\frac{E_r h_r^3}{12(1-\nu_r^2)},\qquad
T_{B,r}=L_r^2\sqrt{\frac{\sigma_{m,r}}{B_r}},
\]

\[
U_{B,r}=\frac{L_r}{T_{B,r}},\qquad
U_{*,r}^t=\sqrt{(U_r^t)^2+U_{B,r}^2+U_{\min}^2},
\]

\[
a_{*,r}^t=\frac{(U_{*,r}^t)^2}{L_r}.
\]

Thus a zero-wind turning point still has a nonzero structural scale and can produce elastic restoring and damping acceleration.

## 5. Rank-2-stable shell maps

Planar shell neighborhoods are handled in a 2D tangent domain. A `3 x 2` tangent map is fitted and then extended with an explicit normal/thickness rule:

\[
F^{\mathrm{shell}}
=F_{\parallel}(T^0)^\top
+\lambda_n n^t(n^0)^\top.
\]

The previous direct inverse of a nearly rank-2 `3 x 3` covariance is removed from the main path.

## 6. Surface-aware affine MLS is mandatory in Version 0

Normalized RBF displacement blending reproduces translation but does not generally reproduce rigid or affine motion. Revision 2 uses fixed-support surface-aware affine MLS:

\[
F_{j,\parallel}^{\mathrm{MLS}}
=C_j^{t\xi}(C_j^{\xi\xi})^{-1},
\]

\[
\mu_j^t=\bar p_j^t+\overline F_j^{\mathrm{MLS},t}(\mu_j^0-\bar p_j^0),
\]

\[
\Sigma_j^t=\overline F_j^{\mathrm{MLS},t}\Sigma_j^0
(\overline F_j^{\mathrm{MLS},t})^\top.
\]

Rigid-transform and in-plane affine tests are Version-0 merge gates.

## 7. Mesh pin and reaction projection

The training pipeline explicitly projects:

- continuous pin strength,
- hard-pin companion mask,
- target attachment position and velocity,
- constraint reaction force.

The provisional reaction projection conserves net force by construction. A constrained least-squares correction is specified when net torque/wrench conservation is required for momentum losses and evaluation.

## Required implementation gates

Before response-network training, the repository should pass:

1. area and mass conservation,
2. reliability-gate non-cancellation,
3. zero-wind structural-scale test,
4. rank-2 shell-map conditioning,
5. pin/reaction force and wrench conservation,
6. MLS identity, translation, rigid, and in-plane affine tests,
7. covariance SPD test.
