# 3DGS Wind Response Idea Sketch — Build Note

## Included files

- `3dgs_mesh_privileged_local_global_wind_response_2026-08-05.tex`: authoritative idea sketch and implementation specification.
- `refs_3dgs_wind_response.bib`: bibliography used by the LaTeX source.
- `3dgs_mesh_privileged_local_global_wind_response_2026-08-05.pdf`: compiled 66-page PDF.

## Recommended build

The document uses XeLaTeX because it contains Korean and mixed Latin/math text.

```bash
xelatex 3dgs_mesh_privileged_local_global_wind_response_2026-08-05.tex
bibtex 3dgs_mesh_privileged_local_global_wind_response_2026-08-05
xelatex 3dgs_mesh_privileged_local_global_wind_response_2026-08-05.tex
xelatex 3dgs_mesh_privileged_local_global_wind_response_2026-08-05.tex
```

When the `bibtex` executable is unavailable but `bibtex8` is installed, replace the second command with:

```bash
bibtex8 3dgs_mesh_privileged_local_global_wind_response_2026-08-05.aux
```

## Font requirements

The source requests:

- DejaVu Serif / Sans / Sans Mono
- Noto Sans CJK KR
- Noto Sans Mono CJK KR

Do not commit local font files to the repository. Install equivalent system fonts or change the font declarations in the preamble.

## Architectural status

This document supersedes the previous persistent runtime mesh-proxy design. Source meshes are training-only privileged teachers; runtime object input remains a static 3DGS plus wind, material, and constraint controls.
